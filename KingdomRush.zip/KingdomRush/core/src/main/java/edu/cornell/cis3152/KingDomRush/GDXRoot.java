package edu.cornell.cis3152.KingDomRush;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;
import java.util.Iterator;

public class GDXRoot extends ApplicationAdapter {

    // ===================== DU LIEU CHUNG =====================
    private static final float[][] PATH = {
        {40, 80}, {160, 80}, {160, 240}, {430, 240}, {430, 420}
    };
    private static final float[][] SPOTS = {
        {90, 170}, {250, 150}, {340, 320}, {520, 300}
    };

    // Loai thap: 0 = Cung thu, 1 = Phao (no lan), 2 = Phap su (lam cham)
    private static final String[] TOWER_NAMES = {"Cung", "Phao", "Phap su"};
    private static final int[] TOWER_COST = {50, 100, 80};
    private static final float[] TOWER_RANGE = {120f, 110f, 100f};
    private static final float[] TOWER_CD = {0.7f, 1.8f, 1.2f};
    private static final int[] TOWER_DMG = {10, 30, 12};
    private static final int MAX_LEVEL = 3;

    private static final int TOTAL_WAVES = 10;

    private static final int PLAYING = 0, GAME_OVER = 1, VICTORY = 2;

    // ===================== TRANG THAI =====================
    private ShapeRenderer shape;
    private SpriteBatch batch;
    private BitmapFont font;
    private Viewport viewport;

    private final Tower[] towerAt = new Tower[SPOTS.length];
    private final ArrayList<Enemy> enemies = new ArrayList<>();
    private final ArrayList<Bullet> bullets = new ArrayList<>();
    private final ArrayList<Integer> queue = new ArrayList<>();

    private int state;
    private int gold, lives, wave;
    private float spawnTimer, waveDelay;
    private int selected; // o dat thap dang chon, -1 neu khong

    @Override
    public void create() {
        shape = new ShapeRenderer();
        batch = new SpriteBatch();
        font = new BitmapFont();
        viewport = new FitViewport(640, 480);
        reset();
    }

    private void reset() {
        for (int i = 0; i < towerAt.length; i++) towerAt[i] = null;
        enemies.clear();
        bullets.clear();
        queue.clear();
        state = PLAYING;
        gold = 120;
        lives = 10;
        wave = 0;
        spawnTimer = 0;
        waveDelay = 3f;
        selected = -1;
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    // ===================== VONG LAP CHINH =====================
    @Override
    public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 0.05f);
        handleInput();
        update(dt);

        ScreenUtils.clear(0.22f, 0.42f, 0.18f, 1f);
        viewport.apply();
        shape.setProjectionMatrix(viewport.getCamera().combined);
        batch.setProjectionMatrix(viewport.getCamera().combined);

        // ---- Ve hinh khoi ----
        shape.begin(ShapeRenderer.ShapeType.Filled);

        shape.setColor(0.30f, 0.52f, 0.24f, 1f);
        shape.rect(0, 0, 640, 480);

        drawGrass(35, 180);
        drawGrass(210, 60);
        drawGrass(280, 390);
        drawGrass(500, 100);
        drawGrass(560, 390);
        drawGrass(350, 450);

        shape.setColor(0.25f, 0.18f, 0.12f, 1f);
        drawRoad(64);
        shape.setColor(0.48f, 0.34f, 0.22f, 1f);
        drawRoad(56);
        shape.setColor(0.62f, 0.46f, 0.30f, 1f);
        drawRoad(48);
        drawRoadDetails();

        drawTree(70, 330);
        drawTree(260, 370);
        drawTree(550, 210);
        drawTree(550, 440);
        drawTree(300, 70);

        drawRock(220, 440);
        drawRock(490, 100);
        drawRock(570, 350);

        for (int i = 0; i < SPOTS.length; i++) {
            if (towerAt[i] == null) drawTowerSpot(SPOTS[i][0], SPOTS[i][1]);
        }

        shape.setColor(Color.GREEN);
        shape.circle(40, 80, 13);
        drawBase();

        for (Tower t : towerAt) if (t != null) t.draw(shape);
        for (Enemy e : enemies) e.draw(shape);
        for (Bullet b : bullets) b.draw(shape);

        // Nut menu
        if (state == PLAYING && selected != -1) {
            float[][] rects = menuRects();
            for (float[] r : rects) {
                shape.setColor(0.1f, 0.1f, 0.1f, 1f);
                shape.rect(r[0] - 2, r[1] - 2, r[2] + 4, r[3] + 4);
                shape.setColor(0.85f, 0.75f, 0.45f, 1f);
                shape.rect(r[0], r[1], r[2], r[3]);
            }
        }
        shape.end();

        // Vong tron tam ban cua thap dang chon
        if (state == PLAYING && selected != -1 && towerAt[selected] != null) {
            Tower t = towerAt[selected];
            shape.begin(ShapeRenderer.ShapeType.Line);
            shape.setColor(Color.WHITE);
            shape.circle(t.x, t.y, t.range());
            shape.end();
        }

        // ---- Chu / HUD ----
        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, "Vang: " + gold + "   Mang: " + lives
            + "   Wave: " + Math.max(wave, 1) + "/" + TOTAL_WAVES, 10, 470);

        if (state == PLAYING) {
            if (queue.isEmpty() && enemies.isEmpty() && wave < TOTAL_WAVES) {
                font.draw(batch, "Wave tiep theo sau " + (int) Math.ceil(waveDelay)
                    + "s (SPACE de goi som)", 10, 20);
            } else {
                font.setColor(Color.LIGHT_GRAY);
                font.draw(batch, "Bam o tron de xay / nang cap / ban thap", 10, 20);
            }

            if (selected != -1) {
                String[] labels = menuLabels();
                float[][] rects = menuRects();
                font.setColor(Color.BLACK);
                for (int i = 0; i < labels.length; i++) {
                    font.draw(batch, labels[i], rects[i][0] + 6, rects[i][1] + 19);
                }
            }
        } else if (state == GAME_OVER) {
            font.setColor(Color.RED);
            font.draw(batch, "GAME OVER - bam chuot hoac nhan R de choi lai", 170, 250);
        } else {
            font.setColor(Color.GOLD);
            font.draw(batch, "CHIEN THANG! - bam chuot hoac nhan R de choi lai", 160, 250);
        }
        batch.end();
    }

    // ===================== INPUT =====================
    private void handleInput() {
        if (Gdx.input.isKeyJustPressed(Input.Keys.R)) {
            reset();
            return;
        }
        if (state != PLAYING) {
            if (Gdx.input.justTouched()) reset();
            return;
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)
            && queue.isEmpty() && enemies.isEmpty()) {
            waveDelay = 0;
        }
        if (!Gdx.input.justTouched()) return;

        Vector2 p = viewport.unproject(new Vector2(Gdx.input.getX(), Gdx.input.getY()));

        // 1. Bam vao nut menu?
        if (selected != -1) {
            float[][] rects = menuRects();
            for (int k = 0; k < rects.length; k++) {
                float[] r = rects[k];
                if (p.x >= r[0] && p.x <= r[0] + r[2] && p.y >= r[1] && p.y <= r[1] + r[3]) {
                    onMenuClick(k);
                    return;
                }
            }
        }

        // 2. Bam vao o dat thap?
        for (int i = 0; i < SPOTS.length; i++) {
            if (p.dst(SPOTS[i][0], SPOTS[i][1]) <= 25) {
                selected = (selected == i) ? -1 : i;
                return;
            }
        }

        // 3. Bam cho khac -> dong menu
        selected = -1;
    }

    private void onMenuClick(int k) {
        Tower t = towerAt[selected];
        if (t == null) {
            // Xay thap moi: k = loai thap
            if (gold >= TOWER_COST[k]) {
                gold -= TOWER_COST[k];
                towerAt[selected] = new Tower(k, SPOTS[selected][0], SPOTS[selected][1]);
                selected = -1;
            }
        } else if (k == 0) {
            // Nang cap
            if (t.level < MAX_LEVEL && gold >= t.upgradeCost()) {
                gold -= t.upgradeCost();
                t.invested += t.upgradeCost();
                t.level++;
            }
        } else {
            // Ban thap (hoan 60%)
            gold += (int) (t.invested * 0.6f);
            towerAt[selected] = null;
            selected = -1;
        }
    }

    private String[] menuLabels() {
        Tower t = towerAt[selected];
        if (t == null) {
            String[] s = new String[3];
            for (int i = 0; i < 3; i++) s[i] = TOWER_NAMES[i] + " " + TOWER_COST[i];
            return s;
        }
        return new String[] {
            t.level < MAX_LEVEL ? "Nang cap " + t.upgradeCost() : "Cap toi da",
            "Ban +" + (int) (t.invested * 0.6f)
        };
    }

    private float[][] menuRects() {
        int n = towerAt[selected] == null ? 3 : 2;
        float w = 96, h = 26;
        float x = Math.max(5, Math.min(640 - w - 5, SPOTS[selected][0] - w / 2));
        float baseY = SPOTS[selected][1] + 32;
        float[][] r = new float[n][];
        for (int i = 0; i < n; i++) {
            r[i] = new float[] {x, baseY + (n - 1 - i) * (h + 4), w, h};
        }
        return r;
    }

    // ===================== LOGIC =====================
    private void update(float dt) {
        if (state != PLAYING) return;

        // Sinh quai
        if (!queue.isEmpty()) {
            spawnTimer -= dt;
            if (spawnTimer <= 0) {
                int type = queue.remove(0);
                enemies.add(new Enemy(type, 30 + wave * 14));
                spawnTimer = 0.9f;
            }
        } else if (enemies.isEmpty()) {
            if (wave >= TOTAL_WAVES) {
                state = VICTORY;
                return;
            }
            waveDelay -= dt;
            if (waveDelay <= 0) startWave();
        }

        // Quai
        Iterator<Enemy> ei = enemies.iterator();
        while (ei.hasNext()) {
            Enemy e = ei.next();
            e.update(dt);
            if (e.reachedEnd) {
                lives -= (e.type == 2) ? 2 : 1;
                ei.remove();
            } else if (e.hp <= 0) {
                gold += e.reward();
                ei.remove();
            }
        }
        if (lives <= 0) {
            lives = 0;
            state = GAME_OVER;
            return;
        }

        // Thap
        for (Tower t : towerAt) if (t != null) t.update(dt, enemies, bullets);

        // Dan
        Iterator<Bullet> bi = bullets.iterator();
        while (bi.hasNext()) {
            Bullet b = bi.next();
            b.update(dt, enemies);
            if (b.done) bi.remove();
        }
    }

    private void startWave() {
        wave++;
        if (wave > 1) gold += 20; // thuong khi qua wave
        int count = 5 + wave * 2;
        for (int i = 0; i < count; i++) {
            int type = 0;                               // thuong
            if (wave >= 2 && i % 3 == 2) type = 1;      // nhanh
            if (wave >= 3 && i % 5 == 4) type = 2;      // trau
            queue.add(type);
        }
        spawnTimer = 0;
        waveDelay = 4f;
    }

    // ===================== ENEMY =====================
    // type: 0 = thuong, 1 = nhanh (it mau), 2 = trau (nhieu mau, cham)
    static class Enemy {
        float x = PATH[0][0], y = PATH[0][1];
        float hp, maxHp, speed;
        int type, next = 1;
        float slowTimer = 0;
        boolean reachedEnd = false;

        Enemy(int type, float baseHp) {
            this.type = type;
            if (type == 1) { hp = baseHp * 0.6f; speed = 100f; }
            else if (type == 2) { hp = baseHp * 3f; speed = 35f; }
            else { hp = baseHp; speed = 60f; }
            maxHp = hp;
        }

        int reward() { return type == 2 ? 25 : (type == 1 ? 12 : 10); }

        void update(float dt) {
            if (slowTimer > 0) slowTimer -= dt;
            float step = speed * (slowTimer > 0 ? 0.5f : 1f) * dt;
            float tx = PATH[next][0], ty = PATH[next][1];
            float dx = tx - x, dy = ty - y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist <= step) {
                x = tx; y = ty;
                next++;
                if (next >= PATH.length) reachedEnd = true;
            } else {
                x += dx / dist * step;
                y += dy / dist * step;
            }
        }

        float progress() {
            if (next >= PATH.length) return next * 1000f;
            return next * 1000f - (float) Math.hypot(PATH[next][0] - x, PATH[next][1] - y);
        }

        void draw(ShapeRenderer s) {
            float r = (type == 2) ? 14 : (type == 1 ? 8 : 10);
            if (type == 1) s.setColor(0.9f, 0.6f, 0.1f, 1f);
            else if (type == 2) s.setColor(0.4f, 0.1f, 0.4f, 1f);
            else s.setColor(0.7f, 0.1f, 0.1f, 1f);
            s.circle(x, y, r);
            if (slowTimer > 0) {
                s.setColor(0.4f, 0.7f, 1f, 1f);
                s.circle(x, y, r * 0.5f);
            }
            s.setColor(0.2f, 0.2f, 0.2f, 1f);
            s.rect(x - 12, y + r + 3, 24, 3);
            s.setColor(Color.GREEN);
            s.rect(x - 12, y + r + 3, 24 * Math.max(hp, 0) / maxHp, 3);
        }
    }

    // ===================== TOWER =====================
    static class Tower {
        final int type;
        final float x, y;
        int level = 1;
        int invested;
        float timer = 0;

        Tower(int type, float x, float y) {
            this.type = type; this.x = x; this.y = y;
            this.invested = TOWER_COST[type];
        }

        float range() { return TOWER_RANGE[type] + (level - 1) * 12f; }
        float cooldown() { return TOWER_CD[type] * (1f - (level - 1) * 0.12f); }
        int damage() { return (int) (TOWER_DMG[type] * (1f + (level - 1) * 0.6f)); }
        int upgradeCost() { return (int) (TOWER_COST[type] * 0.7f * level); }

        void update(float dt, ArrayList<Enemy> enemies, ArrayList<Bullet> bullets) {
            timer -= dt;
            if (timer > 0) return;
            Enemy best = null;
            for (Enemy e : enemies) {
                if (e.hp <= 0) continue;
                if (Math.hypot(e.x - x, e.y - y) <= range()) {
                    if (best == null || e.progress() > best.progress()) best = e;
                }
            }
            if (best != null) {
                bullets.add(new Bullet(type, x, y + 15, best, damage()));
                timer = cooldown();
            }
        }

        void draw(ShapeRenderer s) {
            s.setColor(0.25f, 0.2f, 0.15f, 1f);
            s.circle(x, y, 22);
            s.setColor(0.45f, 0.45f, 0.55f, 1f);
            s.rect(x - 10, y - 10, 20, 28);
            if (type == 0) s.setColor(0.2f, 0.6f, 0.2f, 1f);
            else if (type == 1) s.setColor(0.3f, 0.3f, 0.3f, 1f);
            else s.setColor(0.2f, 0.4f, 0.9f, 1f);
            s.triangle(x - 12, y + 18, x + 12, y + 18, x, y + 32);
            // cham vang = cap thap
            s.setColor(Color.GOLD);
            for (int i = 0; i < level; i++) s.circle(x - 8 + i * 8, y - 16, 3);
        }
    }

    // ===================== BULLET =====================
    static class Bullet {
        float x, y;
        final int type, damage;
        final Enemy target;
        boolean done = false;

        Bullet(int type, float x, float y, Enemy target, int damage) {
            this.type = type; this.x = x; this.y = y;
            this.target = target; this.damage = damage;
        }

        void update(float dt, ArrayList<Enemy> enemies) {
            if (target.hp <= 0 || target.reachedEnd) { done = true; return; }
            float speed = (type == 1) ? 220f : 320f;
            float dx = target.x - x, dy = target.y - y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            float step = speed * dt;
            if (dist <= step) {
                hit(enemies);
                done = true;
            } else {
                x += dx / dist * step;
                y += dy / dist * step;
            }
        }

        private void hit(ArrayList<Enemy> enemies) {
            if (type == 1) { // phao: sat thuong lan
                for (Enemy e : enemies) {
                    if (Math.hypot(e.x - target.x, e.y - target.y) <= 45) e.hp -= damage;
                }
            } else {
                target.hp -= damage;
                if (type == 2) target.slowTimer = 2f; // phap su: lam cham
            }
        }

        void draw(ShapeRenderer s) {
            if (type == 0) s.setColor(Color.YELLOW);
            else if (type == 1) s.setColor(Color.DARK_GRAY);
            else s.setColor(Color.CYAN);
            s.circle(x, y, type == 1 ? 5 : 3);
        }
    }

    // ===================== HAM VE MAP =====================
    private void drawRoad(float width) {
        shape.rectLine(40, 80, 160, 80, width);
        shape.rectLine(160, 80, 160, 240, width);
        shape.rectLine(160, 240, 430, 240, width);
        shape.rectLine(430, 240, 430, 420, width);

        shape.circle(160, 80, width / 2);
        shape.circle(160, 240, width / 2);
        shape.circle(430, 240, width / 2);
    }

    private void drawGrass(float x, float y) {
        shape.setColor(0.18f, 0.38f, 0.15f, 1f);
        shape.circle(x, y, 5);
        shape.circle(x + 8, y + 3, 5);
        shape.circle(x + 15, y, 4);

        shape.setColor(0.48f, 0.68f, 0.30f, 1f);
        shape.circle(x + 4, y + 4, 2);
    }

    private void drawTree(float x, float y) {
        shape.setColor(0.35f, 0.20f, 0.10f, 1f);
        shape.rect(x - 5, y - 17, 10, 27);

        shape.setColor(0.12f, 0.30f, 0.12f, 1f);
        shape.circle(x, y + 12, 20);

        shape.setColor(0.20f, 0.43f, 0.16f, 1f);
        shape.circle(x - 9, y + 15, 12);
        shape.circle(x + 9, y + 18, 12);

        shape.setColor(0.30f, 0.53f, 0.20f, 1f);
        shape.circle(x, y + 22, 10);
    }

    private void drawRock(float x, float y) {
        shape.setColor(0.25f, 0.25f, 0.23f, 1f);
        shape.circle(x, y, 12);

        shape.setColor(0.48f, 0.48f, 0.43f, 1f);
        shape.circle(x - 3, y + 3, 8);
    }

    private void drawRoadDetails() {
        shape.setColor(0.78f, 0.62f, 0.42f, 1f);
        shape.circle(80, 80, 2);
        shape.circle(130, 80, 2);
        shape.circle(160, 120, 2);
        shape.circle(160, 180, 2);
        shape.circle(220, 240, 2);
        shape.circle(300, 240, 2);
        shape.circle(370, 240, 2);
        shape.circle(430, 300, 2);
        shape.circle(430, 370, 2);
    }

    private void drawTowerSpot(float x, float y) {
        shape.setColor(0.22f, 0.22f, 0.18f, 1f);
        shape.circle(x, y, 25);

        shape.setColor(0.66f, 0.62f, 0.48f, 1f);
        shape.circle(x, y, 21);

        shape.setColor(0.40f, 0.38f, 0.29f, 1f);
        shape.circle(x, y, 15);
    }

    private void drawBase() {
        shape.setColor(0.30f, 0.25f, 0.20f, 1f);
        shape.rect(410, 400, 40, 35);

        shape.setColor(0.68f, 0.60f, 0.43f, 1f);
        shape.rect(415, 405, 30, 25);

        shape.setColor(Color.GOLD);
        shape.rect(425, 410, 10, 15);

        shape.setColor(0.35f, 0.25f, 0.16f, 1f);
        shape.rect(412, 435, 8, 8);
        shape.rect(440, 435, 8, 8);
    }

    @Override
    public void dispose() {
        shape.dispose();
        batch.dispose();
        font.dispose();
    }
}
