package game;

import base.Base;
import enemy.Enemy;
import enemy.EnemyFactory;
import enemy.EnemyType;
import path.Path;
import player.Player;
import tower.Tower;
import wave.Wave;
import wave.WaveManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GameManager {
    private Base base;
    private List<Enemy> enemies;

    public GameManager() {
        base = new Base();
        enemies = new ArrayList<>();
        towers = new ArrayList<>();
        player = new Player();
    }

    public void addEnemy(Enemy enemy) {
        enemies.add(enemy);
    }

    public void updateEnemies(float deltaTime) {
        for(Enemy enemy: enemies) {
            enemy.followPath(deltaTime);
        }
    }

    public void checkEnemies() {
        Iterator<Enemy>  iterator = enemies.iterator();

        while(iterator.hasNext()) {
            Enemy enemy = iterator.next();

            if(!enemy.isAlive()) {
                iterator.remove();
                player.addGold(enemy.getGoldReward());
                System.out.println("Enemy died!");
                System.out.println("Gold: " + player.getGold());
            }

            else if(enemy.hasReachedEnd()) {
                base.takeDamage();
                iterator.remove();
                System.out.println("Base health: " + base.getHealth());
            }
        }
    }

    public void displayBaseHealth() {
        System.out.println("Base HP: " + base.getHealth());
    }

    public boolean isGameOver() {
        return base.displayHealth();
    }

    public boolean isVictory() {
        return allWavesCompleted && enemies.isEmpty();
    }

    public void checkGameStatus() {
        if(isGameOver()) {
            System.out.println("Game Over");
        }
        else if(isVictory()) {
            System.out.println("Victory");
        }
    }

    public void startGame(Wave wave) {
        nextEnemyIndex = 0;
        spawnTimer = 0;

        waveStarted = true;

        System.out.println("Starting Wave "
                + wave.getWaveNumber());
    }

    public boolean isWaveCleared(Wave wave) {
        boolean allWaveSpawned = nextEnemyIndex >= wave.getEnemies().size();

        boolean noEnemiesRemaining = enemies.isEmpty(); // ko con quai nao

        return allWaveSpawned && noEnemiesRemaining;
    }

    private boolean waveStarted = false;
    private boolean allWavesCompleted = false;

    public void startCurrentWave(WaveManager  waveManager) {
        if(!waveManager.hasNextWave()) {
            allWavesCompleted = true;
            System.out.println("All waves completed!");
            return;
        }

        Wave wave = waveManager.getCurrentWave();
        startGame(wave);
        waveStarted = true;
    }

    public void updateWave(WaveManager waveManager) {
        Wave currentWave = waveManager.getCurrentWave();

        if (waveStarted && isWaveCleared(currentWave)) {
            waveStarted = false;
            waveManager.nextWave();

            startCurrentWave(waveManager);
        }
    }

    private float spawnTimer = 0;
    private float spawnInterval = 2.0f;
    private int nextEnemyIndex = 0;

    public void updateSpawning(float deltaTime, Wave wave) {
        spawnTimer += deltaTime;

        while (spawnTimer >= spawnInterval
                && nextEnemyIndex < wave.getEnemies().size()) {

            EnemyType type = wave.getEnemyType(nextEnemyIndex);

            Enemy enemy = EnemyFactory.createEnemy(type);

            enemy.setPath(path);

// Đặt Enemy tại điểm đầu tiên của Path
            enemy.setPosition(
                    path.getPoint(0).getX(),
                    path.getPoint(0).getY()
            );

            addEnemy(enemy);

            nextEnemyIndex++;

            spawnTimer -= spawnInterval;
        }
    }

    public void checkWaveStatus(WaveManager waveManager) {
        Wave wave = waveManager.getCurrentWave();

        if(wave!=null && isWaveCleared(wave)) {
            waveStarted = false;
            waveManager.nextWave();

            startCurrentWave(waveManager);
        }
    }

// UPDATEGAME
    public void updateGame(float deltaTime, WaveManager waveManager) {
        if(allWavesCompleted) {
            return;
        }

        if(!waveStarted) {
            startCurrentWave(waveManager);
        }

        Wave wave = waveManager.getCurrentWave();

        if(wave == null) {
            allWavesCompleted = true;
            return;
        }

        updateSpawning(deltaTime, wave);
        updateEnemies(deltaTime);
        updateTowers(deltaTime);
        checkEnemies();

        checkWaveStatus(waveManager);

        checkGameStatus();
    }

//Kết nối Player với GameManager
    private Player player;

    public Player getPlayer() {
        return player;
    }

    //MUA TOWER
    private List<Tower> towers;


    public boolean buyTower(Tower tower) {
        if(player.spendGold(tower.getCost())) {
            towers.add(tower);
            return true;
        }

        return false;
    }

    public boolean placeTower(Tower tower, float x, float y, Path path) {
        //Kiem tra tower co qua gan duong di khong
        if(path.isNearPath(x,y,50)) {
            System.out.println("Cannot place tower near path!");
            return false;
        }

        if(isTowerOverlapping(x,y,60)) {
            System.out.println("Tower position is occupied!");
            return false;
        }

        if(!player.spendGold(tower.getCost())) {
            System.out.println("Not enough gold!");
            return  false;
        }

        tower.setPosition(x,y);
        towers.add(tower);

        return true;
    }

    public boolean isTowerOverlapping(float x, float y, float minDistance) {
        for(Tower tower : towers) {
            float dx = x - tower.getX();
            float dy = y - tower.getY();

            float distance =(float) Math.sqrt(dx*dx + dy*dy);

            if(distance < minDistance) {
                return true;
            }
        }

        return false;
    }

    public boolean sellTower(Tower tower) {
        if(towers.remove(tower)) {
            int refund = tower.getCost() / 2;
            player.addGold(refund);

            System.out.println("Sold tower! Received " + refund + " gold.");
        }

        return false;
    }

    public boolean upgradeTower(Tower tower) {
        if(!towers.contains(tower)) {
            return false;
        }

        if(tower.getUpgradeLevel() > tower.getMaxUpgradelevel()) {
            return false;
        }

        if(!player.spendGold(tower.getUpgradeCost())) {
            return false;
        }

        tower.upgrade();

        tower.increaseUpgradeCost(50);

        return true;
    }

    public void displayTowerInfo(Tower tower) {
        if(!towers.contains(tower)) {
            System.out.println("Not enough tower!");
            return;
        }

        tower.displayInfo();
    }

    public void updateTowers(float deltaTime) {
        for(Tower tower : towers) {
            tower.update(deltaTime,enemies);
        }
    }

    private Path path;
    public void setPath(Path path) {
        this.path = path;
    }
}
