package base;

public class Base {
    private int health;

    public Base() {
        this.health = 20;
    }

    public int getHealth() {
        return health;
    }

    public void takeDamage() {
        health--;
        if (health <= 0) {
            health = 0;
        }
    }

    public boolean displayHealth() {
        return health <= 0;
    }
}
