package tower;

import enemy.Enemy;

public class MageTower extends Tower {
    public MageTower() {
        super("Mage Tower", 50,4.0F,150);
    }

    @Override
    public void attack(Enemy enemy) {
        if(isInRange(enemy)) {
            System.out.println("Mage Tower casts a magic spell");
            enemy.takeDamage(getDamage());
        } else {
            System.out.println("Enemy is out of range!");
        }
    }

    @Override
    public void upgrade() {
        setDamage(getDamage()+20);
        setRange(getRange()+10);
        setUpgradeLevel(getUpgradeLevel()+1);
    }
}
