package tower;

import enemy.Enemy;

public class ArcherTower extends  Tower {
    public ArcherTower() {
        super("Archer Tower",20,5.0F,100);
    }

    @Override
    public void attack(Enemy enemy) {
        if(isInRange(enemy)) {
            System.out.println("Archer Tower shoots an arrow!");
            enemy.takeDamage(getDamage());
        } else {
            System.out.println("Enemy is out of range!");
        }
    }

    @Override
    public void upgrade() {
        setDamage(getDamage()+5);
        setRange(getRange()+30);
        setUpgradeLevel(getUpgradeLevel()+1);
    }
}
