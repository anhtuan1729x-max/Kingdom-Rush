package tower;

import enemy.Enemy;

public class ArtilleryTower extends Tower {
    public ArtilleryTower() {
        super("Artillery Tower",80,3.0F,200);
    }

    @Override
    public void attack(Enemy enemy) {
        if(isInRange(enemy)) {
            System.out.println("Artillery Tower launches an explosive attack!");
            enemy.takeDamage(getDamage());
        } else {
            System.out.println("Enemy is out of range!");
        }
    }

    @Override
    public void upgrade() {
        setDamage(getDamage()+15);
        setRange(getRange()+15);
        setUpgradeLevel(getUpgradeLevel()+1);
    }
}
