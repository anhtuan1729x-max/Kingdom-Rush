package tower;

import enemy.Enemy;

import java.util.List;

public abstract class Tower {
    private String name;
    private int damage;
    private float range;
    private int cost;

    public Tower(String name, int damage, float range, int cost) {
        this.name = name;
        this.damage = damage;
        this.range = range;
        this.cost = cost;
    }

    public void attack(Enemy enemy) {
        System.out.println(name + " attacks " + enemy.getName());

        enemy.takeDamage(damage);
    }

    public void displayInfo() {
        System.out.println("Tower: " + name);
        System.out.println("Level: " + upgradeLevel);
        System.out.println("Damage: " + getDamage());
        System.out.println("Range: " + getRange());
        System.out.println("Upgrade Cost: " + upgradeCost);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public float getRange() {
        return range;
    }

    public void setRange(float range) {
        this.range = range;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

//Toa do
    private float x;
    private float y;

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

//Tầm bắn
    public boolean isInRange(Enemy enemy) {
        double distance = Math.sqrt(
                Math.pow(enemy.getX()-x,2) +
                Math.pow(enemy.getY()-y,2)
        );
        return distance <= range;
    }

    private int upgradeLevel = 1;
    private int upgradeCost = 100;
    private int maxUpgradelevel = 3;

    // Getter
    public int getUpgradeLevel() {
        return upgradeLevel;
    }

    public void setUpgradeLevel(int upgradeLevel) {
        this.upgradeLevel = upgradeLevel;
    }

    public int getUpgradeCost() {
        return upgradeCost;
    }

    public void setUpgradeCost(int upgradeCost) {
        this.upgradeCost = upgradeCost;
    }

    public int getMaxUpgradelevel() {
        return maxUpgradelevel;
    }

    public void setMaxUpgradelevel(int maxUpgradelevel) {
        this.maxUpgradelevel = maxUpgradelevel;
    }

    public abstract void upgrade();

    public void increaseUpgradeCost(int amount) {
        upgradeCost += amount;
    }

    private float attackCooldown = 1.0f;
    private float attackTimer = 0;

    public void update(float deltaTime, List<Enemy> enemies) {
        attackTimer += deltaTime;
        if(attackTimer >= attackCooldown) {
            Enemy target = findTarget(enemies);

            if (target != null) {
                attack(target);
                attackTimer = 0;
            }
        }
    }

    //Tim muc tieu gan nha chinh hon
    public Enemy findTarget(List<Enemy> enemies) {
        Enemy target = null;
        for(Enemy  e: enemies) {
            if(!e.isAlive() || !isInRange(e)) {
                continue;
            }

            if(target == null || e.getCurrentPointIndex() > target.getCurrentPointIndex()) {
                target = e;
            }
        }

        return target;
    }
}
