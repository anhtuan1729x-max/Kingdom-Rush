package enemy;

public enum EnemyType {
    GOBLIN,
    ORC,
    TROLL
}