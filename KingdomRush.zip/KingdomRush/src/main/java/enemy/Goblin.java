package enemy;

public class Goblin extends Enemy{
    public Goblin(){
        super("Goblin",100,10,2.5F,20);
    }

    @Override
    public void move(){
        System.out.println("Goblin is running fast");
    }

}
