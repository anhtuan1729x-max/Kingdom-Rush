package enemy;

import path.Path;
import path.Position;

public abstract class Enemy {
    private String name;
    private int health;
    private int damage;
    private float speed;

    public Enemy(String name, int health, int damage,
                 float speed, int goldReward) {
        this.name = name;
        this.health = health;
        this.damage = damage;
        this.speed = speed;
        this.goldReward = goldReward;
    }

    public void takeDamage(int damage) {
        health -= damage;

        if (health <= 0) {
            health = 0;
        }
    }

    public boolean isAlive() {
        return health > 0;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Health: " + health);
        System.out.println("Damage: " + damage);
        System.out.println("Speed: " + speed);
    }

    public abstract void move();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }


//Toa do
    private float x;
    private float y;

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

//Phuong thuc di chuyen
    public void moveTowards(float targetX, float targetY, float deltaTime) {
        float dx = targetX - x;
        float dy = targetY - y;

        float distance = (float) Math.sqrt(dx * dx + dy * dy);

        if (distance == 0) {
            return;
        }

        float step = speed * deltaTime;

        if(step >= distance) {
            x = targetX;
            y = targetY;
        } else {
            x+=(dx/distance)*step;
            y+=(dy/distance)*step;
        }
    }

    public float distanceTo(float targetX, float targetY) {
        float dx = targetX - x;
        float dy = targetY - y;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private Path path;
    private int currentPointIndex = 0;

    public int getCurrentPointIndex() {
        return currentPointIndex;
    }

    public Path getPath() {
        return path;
    }
    public void setPath(Path path) {
        this.path = path;
    }

    private boolean reachedEnd = false;

    public boolean hasReachedEnd() {
        return reachedEnd;
    }

    public void followPath(float deltaTime) {
        if(reachedEnd || path == null) {
            return;
        }

        if(currentPointIndex >= path.getPointCount()) {
            reachedEnd = true;
            return;
        }

        Position target = path.getPoint(currentPointIndex);

        moveTowards(target.getX(), target.getY(), deltaTime);

        if(distanceTo(target.getX(), target.getY()) < 0.1F) {
            currentPointIndex++;
        }
    }

    private int goldReward;

    public int getGoldReward() {
        return goldReward;
    }

}
