package enemy;

public class Troll extends Enemy{
    public Troll() {
        super("Troll",500,40,0.5F,70);
    }

    @Override
    public void move() {
        System.out.println("Troll is walking slowly");
    }
}
