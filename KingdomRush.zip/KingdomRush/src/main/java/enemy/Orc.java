package enemy;

public class Orc extends Enemy{
    public Orc() {
        super("Orc",300,25,1.0F,40);
    }

    @Override
    public void move() {
        System.out.println("Orc is walking slowly");
    }
}
