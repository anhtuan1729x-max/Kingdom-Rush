package enemy;

public class EnemyFactory {

    public static Enemy createEnemy(EnemyType type) {
        switch (type) {
            case GOBLIN:
                return new Goblin();

            case ORC:
                return new Orc();

            case TROLL:
                return new Troll();

            default:
                throw new IllegalArgumentException("Unknown enemy type!");
        }
    }
}