package path;

import java.util.ArrayList;
import java.util.List;

public class Path {
    private List<Position> points;

    public Path() {
        points = new ArrayList<>();
    }

    public void addPoint(float x, float y) {
        points.add(new Position(x, y));
    }

    public Position getPoint(int index) {
        return points.get(index);
    }

    public int getPointCount() {
        return points.size();
    }

    public boolean isNearPath(float x, float y, float minDistance) {
        int count = getPointCount();
        float minDistSquared = minDistance * minDistance;

        // Path chỉ có 1 điểm: kiểm tra khoảng cách trực tiếp tới điểm đó
        if (count == 1) {
            Position p = getPoint(0);
            float ddx = x - p.getX();
            float ddy = y - p.getY();
            return ddx * ddx + ddy * ddy < minDistSquared;
        }

        for (int i = 0; i < count - 1; i++) {
            Position p1 = getPoint(i);
            Position p2 = getPoint(i + 1);

            float dx = p2.getX() - p1.getX();
            float dy = p2.getY() - p1.getY();
            float lengthSquared = dx * dx + dy * dy;

            float t = 0;
            // Nếu p1 trùng p2 thì giữ t = 0 (điểm gần nhất là p1)
            if (lengthSquared > 0) {
                t = ((x - p1.getX()) * dx + (y - p1.getY()) * dy) / lengthSquared;
                t = Math.max(0, Math.min(1, t));
            }

            float closestX = p1.getX() + t * dx;
            float closestY = p1.getY() + t * dy;

            float distanceX = x - closestX;
            float distanceY = y - closestY;
            float distanceSquared = distanceX * distanceX + distanceY * distanceY;

            if (distanceSquared < minDistSquared) {
                return true;
            }
        }

        return false;
    }
}