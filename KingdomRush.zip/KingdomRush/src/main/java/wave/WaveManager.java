package wave;

import java.util.ArrayList;
import java.util.List;

public class WaveManager {
    private List<Wave> waves;
    private int currentWaveIndex;

    public WaveManager() {
        waves = new ArrayList<>();
        currentWaveIndex = 0;
    }

    public void addWave(Wave wave) {
        waves.add(wave);
    }

    public Wave getCurrentWave() {
        if (currentWaveIndex >= waves.size()) {
            return null;
        }

        return waves.get(currentWaveIndex);
    }

    public void nextWave() {
        currentWaveIndex++;
    }

    public boolean hasNextWave() {
        return currentWaveIndex < waves.size();
    }

}
