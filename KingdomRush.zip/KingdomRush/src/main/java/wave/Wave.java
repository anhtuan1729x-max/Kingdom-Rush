package wave;

import enemy.Enemy;
import enemy.EnemyFactory;
import enemy.EnemyType;


import java.util.ArrayList;
import java.util.List;

public class Wave {
    private int waveNumber;
    private List<EnemyType> enemies;

    public Wave(int waveNumber) {
        this.waveNumber = waveNumber;
        enemies = new ArrayList<>();
    }


    public int getWaveNumber() {
        return waveNumber;
    }

    public List<EnemyType> getEnemies() {
        return enemies;
    }

    public void addEnemy(EnemyType enemy) {
        enemies.add(enemy);
    }

    public void addEnemyByType(EnemyType type) {
        enemies.add(type);
    }

    public EnemyType getEnemyType(int index) {
        return enemies.get(index);
    }

    public int getEnemyCount() {
        return enemies.size();
    }
}
