package player;

import tower.ArcherTower;

public class Player {
    private int gold;

    public Player() {
        this.gold = 500;
    }

    public int getGold() {
        return gold;
    }

    public void addGold(int amount) {
        gold += amount;
    }

    public boolean spendGold(int amount) {
        if(gold >= amount) {
            gold -= amount;
            return true;
        }
        return false;
    }

}
