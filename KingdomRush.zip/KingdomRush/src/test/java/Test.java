import enemy.*;
import game.GameManager;
import path.Path;
import path.Position;
import player.Player;
import tower.ArcherTower;
import tower.MageTower;
import wave.Wave;
import wave.WaveManager;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        GameManager gameManager = new GameManager();
        WaveManager waveManager = new WaveManager();

        Path path = new Path();

        path.addPoint(0, 100);
        path.addPoint(100, 100);
        path.addPoint(100, 300);
        path.addPoint(4400, 300);
        path.addPoint(400, 500);

        gameManager.setPath(path);

        Wave wave1 = new Wave(1);

        wave1.addEnemy(EnemyType.GOBLIN);
        wave1.addEnemy(EnemyType.GOBLIN);
        wave1.addEnemy(EnemyType.GOBLIN);
        wave1.addEnemy(EnemyType.ORC);
        wave1.addEnemy(EnemyType.ORC);

        Wave wave2 = new Wave(2);

        wave2.addEnemy(EnemyType.GOBLIN);
        wave2.addEnemy(EnemyType.GOBLIN);
        wave2.addEnemy(EnemyType.ORC);
        wave2.addEnemy(EnemyType.ORC);
        wave2.addEnemy(EnemyType.TROLL);

        Wave wave3 = new Wave(3);

        wave3.addEnemy(EnemyType.ORC);
        wave3.addEnemy(EnemyType.ORC);
        wave3.addEnemy(EnemyType.TROLL);
        wave3.addEnemy(EnemyType.TROLL);

        waveManager.addWave(wave1);
        waveManager.addWave(wave2);
        waveManager.addWave(wave3);

        ArcherTower archerTower = new ArcherTower();
        MageTower mageTower = new MageTower();

        gameManager.placeTower(archerTower,200,150,path);
        gameManager.placeTower(mageTower,350,250,path);

        float deltaTime = 0.016f;

        while (!gameManager.isGameOver() && !gameManager.isVictory()) {
            gameManager.updateGame(deltaTime,waveManager);

        }

    }
}
